import React from "react";
import "./homepage.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const HomePage = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
  };

  return (
    <div>
      <div className="slider-container">
        <Slider {...settings}>
          <div>
            <img src="/Humaira1.jpg" alt="" className="slider-image" />
          </div>
          <div>
            <img src="/Humaira2.jpg" alt="" className="slider-image" />
          </div>
          <div>
            <img src="/Humaira3.jpg" alt="" className="slider-image" />
          </div>
        </Slider>
      </div>

      <h1 className="judul">Tentang Kami</h1>
      <div className="content-2">
        <p>
          Humaira adalah tempat Restoran cepat saji yang nyaman untuk menikmati makanan berat
          ataupun ringan yang berkualitas. Kami menyajikan makanan dari
          sumber yang terbaik di seluruh dunia. Nikmati suasana santai sambil
          bekerja atau bersantai dengan teman di Humaira.
        </p>
        <p>Mau lihat daftar menu?, tekan tombol di bawah ini.</p>
        <a href="./projects">
          <button className="button-home">Daftar Menu</button>
        </a>
      </div>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div className="footer-section about"></div>
        </div>
        <div className="footer-bottom">
          &copy; Humaira | Dibuat dengan ❤️ oleh Anda
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
