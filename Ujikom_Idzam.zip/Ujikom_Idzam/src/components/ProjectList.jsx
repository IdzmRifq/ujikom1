import React, { useState } from "react";
import ProjectCard from "./ProjectCard";

const ProjectList = ({ projects, onSave }) => {
  const [projectBeingEdited, setProjectBeingEdited] = useState(null);

  const handleEdit = (project) => {
    setProjectBeingEdited(project);
  };

  const cancelEditing = () => {
    setProjectBeingEdited(null);
  };

  return (
    <div className="row">
      {projects.map((project) => (
        <div key={project.id} className="cols-row">
          <ProjectCard project={project} onEdit={handleEdit} />
        </div>
      ))}
    </div>
  );
};

export default ProjectList;
