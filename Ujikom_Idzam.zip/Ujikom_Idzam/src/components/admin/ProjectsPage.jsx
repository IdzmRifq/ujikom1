import React, { Fragment, useEffect, useState } from "react";
import ProjectList from "./ProjectList";
import { projectAPI } from "./projectAPI";
import Project from "./Project";
import "./projectspage.css";

const ProjectsPage = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(undefined);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchCategory, setSearchCategory] = useState(""); // State untuk kategori pencarian

  
  const handleMoreClick = () => {
    setCurrentPage((currentPage) => currentPage + 1);
  };
  
  useEffect(() => {
    const loadProjects = async () => {
      setLoading(true);
      try {
        const data = await projectAPI.get(currentPage);
        if (currentPage === 1) {
          setProjects(data);
        } else {
          setProjects((projects) => [...projects, ...data]);
        }
      } catch (e) {
        if (e instanceof Error) {
          setError(e.message);
        }
      } finally {
        setLoading(false);
      }
    };
    loadProjects();
  }, [currentPage]);
  
  const saveProject = (project) => {
    projectAPI
      .put(project)
      .then((updatedProject) => {
        let updatedProjects = projects.map((p) => {
          return p.id === project.id ? new Project(updatedProject) : p;
        });
        setProjects(updatedProjects);
      })
      .catch((e) => {
        if (e instanceof Error) {
          setError(e.message);
        }
      });
    };
    
    // Fungsi untuk menyaring proyek berdasarkan kategori
    const filterProjectsByCategory = () => {
      if (!searchCategory) {
        return projects; // Jika tidak ada kategori pencarian, kembalikan semua proyek
      }
      return projects.filter((project) =>
      project.strCategory.toLowerCase().includes(searchCategory.toLowerCase())
      );
    };
    
    if (projects.length <= 0) return <div class="loader-container">
    <div class="loader"></div>
    <div class="loader-text">Loading...</div>
  </div>
  

    return (
    <Fragment>
      <h1 className="text1">Daftar Menu</h1>
      <div className="search-bar-container">
        <input
          className="search-bar-input"
          type="text"
          placeholder="Cari berdasarkan kategori"
          value={searchCategory}
          onChange={(e) => setSearchCategory(e.target.value)}
        />
      </div>
      {error && (
        <div className="row">
          <div className="card large error">
            <section>
              <p>
                <span className="icon-alert inverse" />
                {error}
              </p>
            </section>
          </div>
        </div>
      )}
      {/* Menampilkan proyek yang sudah difilter berdasarkan kategori */}
      <ProjectList onSave={saveProject} projects={filterProjectsByCategory()} />
    </Fragment>
  );
};
export default ProjectsPage;
