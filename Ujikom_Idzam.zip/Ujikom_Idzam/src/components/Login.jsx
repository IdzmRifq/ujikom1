import React, { useState } from "react";
import "./login.css";
import { useNavigate } from "react-router";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (event) => {
    event.preventDefault();

    if (username === "admin" && password === "admin") {
      navigate("/admin");
    } else if (username === "user" && password === "user") {
      navigate("/home");
    } else {
      setError("Invalid username or password");
    }
  };

  return (
    <div className="login">
      <form onSubmit={handleLogin}>
        <h2>LOGIN</h2>
        <div className="form-group">
          <input
            className="username input"
            type="text"
            id="username"
            name="username"
            placeholder="Enter Username"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="form-group">
          <input
            className="password input"
            type="password"
            id="password"
            name="password"
            placeholder="Enter Password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {error && <p className="error">{error}</p>}
        <button className="btn" type="submit">
          Submit
        </button>
      </form>
    </div>
  );
}

export default Login;
