import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import "../App.css";

const Navbar = () => {
  const location = useLocation();

  // List of paths where you want to hide the navbar
  const hiddenPaths = ["/"];

  // Check if the current location is in the hiddenPaths array
  const isHidden = hiddenPaths.includes(location.pathname);

  // Logout handler
  const handleLogout = () => {
    const confirmLogout = window.confirm("Apakah anda yakin ingin Logout?");
    if (confirmLogout) {
      // Perform logout actions here
      // For now, let's redirect to the home page
      window.location.href = "/";
    }
  };

  // Render the navbar only if it's not hidden
  return !isHidden ? (
    <header className="sticky">
      <span className="logo">
        <img src="Humaira_logo.png" alt="logo" width={"130"} height={"99"} />
      </span>
      <NavLink to="/home" className="button rounded">
        <span className="icon-home"></span>
        Home
      </NavLink>
      <NavLink to="/projects" className="button rounded">
        Daftar Menu
      </NavLink>
      <button className="button rounded" onClick={handleLogout}>
        Logout
      </button>
    </header>
  ) : null;
};

export default Navbar;
