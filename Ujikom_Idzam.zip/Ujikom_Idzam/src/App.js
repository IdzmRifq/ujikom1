import "./App.css";
import ProjectsPage from "./components/ProjectsPage";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./home/HomePage";
import Navbar from "./components/Navbar";
import Login from "./components/Login";
import Admin from "./components/admin/ProjectsPage"

function App() {
  return (
      <Router>
        <Navbar/>
        <Routes>
          <Route index path="/" element={<Login />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </Router>

  );
}


export default App;
